# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin

from student.models import map

admin.site.register(map)
