# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

from django import forms

import sqlite3

class login(models.Model):
    first_name = models.TextField(default = '')
    last_name = models.TextField(default = '')
    user_name = models.TextField(default = '')
    password = models.TextField(default = '')
    email = models.TextField(default = '')
    user_type = models.TextField(default = '')

    def __str__(self):
        return self.first_name


conn = sqlite3.connect("db.sqlite3")
curs = conn.cursor()

def commit():
    curs.commit()

def close():
    conn.close()
    
def addData(first_name, last_name, user_name, password, email):
    curs.execute("INSERT INTO db VALUES ( first_name, last_name, user_name, password, email)")
    
def signUp(first_name, last_name, user_name, password, email):
    add_data(first_name, last_name, user_name, password, email)
    commit()
    close()
    
##def userType(user_name):
    ##for curs.execute('SELECT * FROM db WHERE symbol=?',user_name):
        ##return curs.execute('SELECTR user_type')
    
