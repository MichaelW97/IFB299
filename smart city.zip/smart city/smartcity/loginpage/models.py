# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

from django import forms

class login(models.Model):
    login = models.TextField()

    def __str__(self):
        return self.login

class Users(models.Model):
    username = models.TextField()
    password = models.TextField()
    userType = models.TextField()
    firstName = models.TextField()
    lastName = models.TextField()
    email = models.TextField()

    def __str__(self):
        return self.username
    
